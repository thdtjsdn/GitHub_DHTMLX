/*
Product Name: dhtmlxDataView 
Version: 5.1.0 
Edition: Standard 
License: content of this file is covered by DHTMLX Commercial or enterpri. Usage outside GPL terms is prohibited. To obtain Commercial or Enterprise license contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

/*
	@author dhtmlx.com
	@license GPL, see license.txt
*/

if (window.dataProcessor && !dataProcessor.prototype.init_original)
	dataProcessor.prototype.connector_init=true;

