[[1,0,"first"],
 [2,0,"middle"],
 [3,0,"last"],
 [4,2,"child"]]