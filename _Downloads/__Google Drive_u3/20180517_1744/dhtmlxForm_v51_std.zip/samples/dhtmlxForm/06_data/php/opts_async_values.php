<?php

header("Content-Type: text/xml");

echo '<?xml version="1.0" encoding="utf-8"?>'.
	'<data>'.
		'<package>1</package>'.
		'<format>2</format>'.
	'</data>';
?>