<?php
	header("Content-Type: text/plain; charset=utf-8");
	print_r($_REQUEST);
?>
