To run data saving samples you need to 
  - set DB configuration in commmon/config.php
  - use common/dump.sql to create test table
 