/*
Product Name: dhtmlxForm 
Version: 5.1.0 
Edition: Standard 
License: content of this file is covered by DHTMLX Commercial or enterpri. Usage outside GPL terms is prohibited. To obtain Commercial or Enterprise license contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

dhtmlXCalendarObject.prototype.draw = function() {
	this.show();
};
dhtmlXCalendarObject.prototype.close = function() {
	this.hide();
};
dhtmlXCalendarObject.prototype.setYearsRange = function() {
	
};

