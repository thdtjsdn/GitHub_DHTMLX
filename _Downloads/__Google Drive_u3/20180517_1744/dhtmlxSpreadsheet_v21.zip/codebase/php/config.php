<?php

// MySQL
$dsn = "mysql:dbname=ssheet;host=localhost;port=3306";
$db_user = "root";
$db_pass = "1";
$db_tick = "`";

// SQLSRV
// $dsn = "sqlsrv:Server=localhost;Database=ssheet";
// $db_user = "ssheet";
// $db_pass = "1";
// $db_tick = "\"";



$db_prefix = "dhx_";
$username = "admin";
$password = "qwert";


?>