/*
Product Name: dhtmlxWindows 
Version: 5.1.0 
Edition: Standard 
License: content of this file is covered by DHTMLX Commercial or enterpri. Usage outside GPL terms is prohibited. To obtain Commercial or Enterprise license contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

dhtmlXWindows.prototype.enableAutoViewport = function(){};
dhtmlXWindows.prototype.setImagePath = function(){};
dhtmlXWindows.prototype.setEffect = function(){};
dhtmlXWindows.prototype.getEffect = function(){};

dhtmlXWindowsCell.prototype.setToFullScreen = function(){};
dhtmlXWindowsCell.prototype.setIcon = function(){};
dhtmlXWindowsCell.prototype.getIcon = function(){};
dhtmlXWindowsCell.prototype.restoreIcon = function(){};
dhtmlXWindowsCell.prototype.clearIcon = function(){};


